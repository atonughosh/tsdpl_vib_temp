# Ensure configuration files exist
def create_config_file():
    """Create or overwrite config.py with necessary configuration."""
    config_code = """
# Wi-Fi Configuration
SSID = "Ramniwas"
PASSWORD = "lasvegas@007"

# OTA Configuration
FIRMWARE_URL = "https://github.com/atonughosh/tsdpl_vib_temp"
NODE_ID = 2

# MQTT Configuration
BROKER = "13.232.192.17"
PORT = 1883
TOPIC = "esp32/data"
REBOOT_TOPIC = "remote_control"
"""
    try:
        with open("config.py", "w") as f:
            f.write(config_code)
        print("config.py created successfully.")
    except Exception as e:
        print(f"Failed to create config.py: {e}")

def create_boot_file():
    """Create or overwrite boot.py with the necessary content."""
    boot_code = """
import gc
import time

try:
    from config import SSID, PASSWORD, FIRMWARE_URL, NODE_ID, BROKER, PORT, TOPIC, REBOOT_TOPIC
except ImportError:
    print("Error: config.py not found!")
    SSID = ""
    PASSWORD = ""
    FIRMWARE_URL = ""
    NODE_ID = ""
    BROKER = ""
    PORT = 1883
    TOPIC = ""
    REBOOT_TOPIC = ""

# OTA update logic
from ota import OTAUpdater
import network
import machine
import uasyncio as asyncio

def connect_wifi():
    #Blocking function to connect to Wi-Fi.
    sta_if = network.WLAN(network.STA_IF)
    sta_if.active(True)

    print("Pausing all tasks while connecting to Wi-Fi...")
    time.sleep(2)  # Allow Wi-Fi adapter to initialize

    for attempt in range(5):  # Retry up to 5 times
        try:
            if not sta_if.isconnected():
                print(f"Connecting to Wi-Fi (Attempt {attempt + 1}/5)...")
                sta_if.connect(SSID, PASSWORD)

                for _ in range(20):  # Wait up to 10 seconds
                    if sta_if.isconnected():
                        print(f"Wi-Fi connected: {sta_if.ifconfig()[0]}")
                        time.sleep(10)  # Pause for stability
                        print("Resuming tasks after Wi-Fi connection.")
                        return

                    time.sleep(0.5)

            if sta_if.isconnected():
                print(f"Wi-Fi already connected: {sta_if.ifconfig()[0]}")
                time.sleep(10)  # Pause for stability
                print("Resuming tasks after Wi-Fi connection.")
                return

        except OSError as e:
            print(f"Wi-Fi connection error: {e}. Retrying...")

        # Exponential backoff before next attempt
        time.sleep(2 ** attempt)

    print("Wi-Fi connection failed after multiple attempts. Rebooting...")
    machine.reset()  # Reboot if all retries fail

def reconnect_wifi():
    #Blocking function to handle Wi-Fi reconnection.
    print("Reconnecting to Wi-Fi and blocking all tasks...")
    connect_wifi()  # Reuse the connect logic

def boot_time_ota():
    # Blocking function to perform OTA updates during boot.
    print("Starting boot time OTA process...")
    try:
        # Ensure Wi-Fi is connected before OTA
        connect_wifi()

        # Perform OTA update
        ota_updater = OTAUpdater(SSID, PASSWORD, FIRMWARE_URL, "main.py", NODE_ID)
        time.sleep(5)  # Allow Wi-Fi to stabilize
        
        # Run check_for_updates asynchronously
        asyncio.run(ota_updater.check_for_updates())  # This will ensure the update check is awaited properly
        
        # Check if an update is available before proceeding
        if ota_updater.latest_version and ota_updater.current_version < ota_updater.latest_version:
            print("New firmware version available. Performing OTA update...")
            ota_updater.update_and_reset()  # Perform update if new version is available
        else:
            print("No firmware updates available.")
    except Exception as e:
        print(f"Error during OTA update: {e}")

    gc.collect()

def boot():
    #Run blocking boot sequence.
    print("Starting boot process...")
    boot_time_ota()  # Ensure OTA is completed before proceeding
    gc.collect()
    print("Boot process completed. Proceeding to main application.")

# Run the boot sequence
boot()
    """
    with open("boot.py", "w") as f:
        f.write(boot_code)
        print("boot.py created successfully.")

create_config_file()
create_boot_file()


import machine
import uasyncio as asyncio
import json
import os
import math
from machine import Pin, I2C, SoftSPI
from umqtt.simple import MQTTClient
import max31865
from ota import OTAUpdater
from config import SSID, PASSWORD, BROKER, PORT, TOPIC, REBOOT_TOPIC, FIRMWARE_URL, NODE_ID
import time
import ujson as json  # Use MicroPython-compatible JSON library

# Constants
RTD_NOMINAL = 100.0
RTD_REFERENCE = 402.0
RTD_WIRES = 3
MPU6050_ADDR = 0x68
PWR_MGMT_1 = 0x6B

# SPI and I2C setup
sck = Pin(18, Pin.OUT)
mosi = Pin(23, Pin.OUT)
miso = Pin(19, Pin.IN)
spi = SoftSPI(baudrate=50000, sck=sck, mosi=mosi, miso=miso, polarity=0, phase=1)
cs1 = Pin(5, Pin.OUT, value=1)
css = [cs1]
sensors = [max31865.MAX31865(spi, cs, wires=RTD_WIRES, rtd_nominal=RTD_NOMINAL, ref_resistor=RTD_REFERENCE) for cs in css]

# I2C setup for MPU6050
scl_pin = Pin(22)
sda_pin = Pin(21)
i2c = I2C(0, scl=scl_pin, sda=sda_pin, freq=400000)

# LED setup
led = Pin(2, Pin.OUT)

# Shared state for MPU6050
mpu6050_initialized = False
offsets = (0, 0, 0)  # Placeholder for accelerometer offsets

# Global MQTT client instance
mqtt_client = None

def get_firmware_version():
    """Read the firmware version from version.json."""
    try:
        with open("version.json", "r") as f:
            version_data = json.load(f)
            return version_data.get("version", "unknown")  # Default to 'unknown' if key is missing
    except Exception as e:
        print(f"Error reading version.json: {e}")
        return "unknown"

def on_message(topic, msg):
    """Handle incoming MQTT messages."""
    try:
        decoded_topic = topic.decode('utf-8')
        decoded_msg = msg.decode('utf-8')
        print(f"Message received on topic {decoded_topic}: {decoded_msg}")

        # Handle reboot command
        if decoded_topic == REBOOT_TOPIC and decoded_msg == "reboot":
            print("Reboot command received. Restarting...")
            machine.reset()
    except Exception as e:
        print(f"Error in on_message callback: {e}")

async def connect_mqtt():
    """Establish a connection to the MQTT broker."""
    global mqtt_client
    try:
        mqtt_client = MQTTClient("esp32_client", BROKER, port=PORT, keepalive=60)
        mqtt_client.set_callback(on_message)
        mqtt_client.connect()
        mqtt_client.subscribe(REBOOT_TOPIC)
        print(f"Connected to MQTT broker at {BROKER}:{PORT} and subscribed to {REBOOT_TOPIC}")
        return mqtt_client
    except Exception as e:
        print(f"MQTT connection failed: {e}")
        return None

async def reconnect_mqtt():
    """Reconnect to the MQTT broker."""
    global mqtt_client
    try:
        if mqtt_client:
            mqtt_client.disconnect()
        print("Reconnecting to MQTT broker...")
        return await connect_mqtt()
    except Exception as e:
        print(f"Error during MQTT reconnection: {e}")
        return None

async def publish_data(client, data):
    """Publish data to the MQTT broker with error handling."""
    if client:
        try:
            print(f"Publishing to topic {TOPIC}: {data}")
            client.publish(TOPIC, data.encode('utf-8'))  # Ensure data is encoded
            print("Publish successful.")
        except Exception as e:
            print(f"Error publishing data: {e}")
            client = await reconnect_mqtt()
    else:
        print("MQTT client is None. Reconnecting...")
        client = await reconnect_mqtt()
    return client

async def check_mqtt_messages(client):
    """Check for incoming MQTT messages."""
    try:
        if client:
            client.check_msg()
        else:
            client = await reconnect_mqtt()
    except Exception as e:
        print(f"Error checking MQTT messages: {e}")
        client = await reconnect_mqtt()
    return client


async def mqtt_task():
    """Handle MQTT connections and messages."""
    global mqtt_client
    mqtt_client = await connect_mqtt()

    while True:
        try:
            if mqtt_client:
                mqtt_client = await check_mqtt_messages(mqtt_client)
                
                # Example sensor data
                ax, ay, az = 1.23, 4.56, 7.89  # Replace with actual sensor readings
                temperature = 25.0  # Replace with actual temperature reading
                
                # Get firmware version from version.json
                firmware_version = get_firmware_version()

                # Prepare the string
                data = (
                    f"AccX: {ax if ax is not None else '0.0'}, "
                    f"AccY: {ay if ay is not None else '0.0'}, "
                    f"AccZ: {az if az is not None else '0.0'}, "
                    f"Temp: {temperature:.2f}C, FW: {firmware_version}"
                )

                mqtt_client = await publish_data(mqtt_client, data)
            else:
                print("MQTT client is disconnected. Reconnecting...")
                mqtt_client = await reconnect_mqtt()
        except Exception as e:
            print(f"Error in MQTT task: {e}")
            mqtt_client = await reconnect_mqtt()

        await asyncio.sleep(5)  # Adjust the interval for your application


async def detect_mpu6050():
    """Check if the MPU6050 is connected."""
    try:
        data = i2c.readfrom_mem(MPU6050_ADDR, 0x75, 1)  # WHO_AM_I register
        detected = data[0] == 0x68  # MPU6050 WHO_AM_I value is 0x68
        print(f"MPU6050 detection status: {'Detected' if detected else 'Not Detected'}")
        return detected
    except Exception as e:
        print(f"Error during MPU6050 detection: {e}")
        return False

async def initialize_mpu6050():
    """Initialize the MPU6050 sensor."""
    global offsets
    try:
        print("Starting MPU6050 initialization...")

        # Reset the MPU6050 (optional but recommended)
        print("Resetting MPU6050...")
        i2c.writeto_mem(MPU6050_ADDR, PWR_MGMT_1, b'\x80')  # Reset MPU6050
        await asyncio.sleep(0.1)  # Short delay for reset to complete

        # Wake up the MPU6050
        print("Waking up MPU6050...")
        i2c.writeto_mem(MPU6050_ADDR, PWR_MGMT_1, b'\x00')

        # Configure basic settings
        print("Configuring MPU6050 registers...")
        i2c.writeto_mem(MPU6050_ADDR, 0x1A, b'\x03')  # Set DLPF to 44Hz
        i2c.writeto_mem(MPU6050_ADDR, 0x1B, b'\x00')  # Set Gyroscope to ±250°/s
        i2c.writeto_mem(MPU6050_ADDR, 0x1C, b'\x00')  # Set Accelerometer to ±2g

        # Perform calibration
        print("Starting calibration...")
        offsets = await calibrate_mpu6050(i2c)  # Pass the I2C object here
        print("Calibration completed successfully.")

        print("MPU6050 initialized successfully.")
        return True
    except Exception as e:
        print(f"Failed to initialize MPU6050: {e}")
        return False

async def calibrate_mpu6050(i2c):
    num_samples = 1000
    ax_offset, ay_offset, az_offset = 0, 0, 0
    for _ in range(num_samples):
        try:
            ax = await read_i2c_word(i2c, 0x3B)
            ay = await read_i2c_word(i2c, 0x3D)
            az = await read_i2c_word(i2c, 0x3F)
            ax_offset += ax
            ay_offset += ay
            az_offset += az
        except Exception as e:
            print(f"Calibration error: {e}")
    ax_offset /= num_samples
    ay_offset /= num_samples
    az_offset /= num_samples
    az_offset -= 16384  # Adjust for gravity
    print(f"Calibration completed: offsets = {ax_offset}, {ay_offset}, {az_offset}")
    return ax_offset, ay_offset, az_offset

async def read_i2c_word(i2c, register):
    data = i2c.readfrom_mem(MPU6050_ADDR, register, 2)
    value = (data[0] << 8) | data[1]
    if value >= 0x8000:
        value -= 0x10000
    return value

async def read_accel(i2c, offsets):
    ax_offset, ay_offset, az_offset = offsets
    try:
        ax = await read_i2c_word(i2c, 0x3B) - ax_offset
        ay = await read_i2c_word(i2c, 0x3D) - ay_offset
        az = await read_i2c_word(i2c, 0x3F) - az_offset
        return ax / 16384.0, ay / 16384.0, az / 16384.0
    except Exception as e:
        print(f"Error reading accelerometer: {e}")
        return 0.0, 0.0, 0.0

async def calculate_rms(i2c, offsets, num_samples=100):
    ax_squared, ay_squared, az_squared = 0, 0, 0
    for _ in range(num_samples):
        ax, ay, az = await read_accel(i2c, offsets)
        ax_squared += ax ** 2
        ay_squared += ay ** 2
        az_squared += az ** 2
    ax_rms = math.sqrt(ax_squared / num_samples)
    ay_rms = math.sqrt(ay_squared / num_samples)
    az_rms = math.sqrt(az_squared / num_samples)
    return ax_rms, ay_rms, az_rms

async def connect_wifi():
    """Ensure Wi-Fi connection with retries and error handling."""
    import network
    sta_if = network.WLAN(network.STA_IF)
    sta_if.active(True)

    # Pause all network-related tasks during Wi-Fi connection
    print("Pausing all tasks while connecting to Wi-Fi...")
    await asyncio.sleep(2)  # Ensure Wi-Fi adapter initializes

    for attempt in range(5):  # Retry up to 5 times
        try:
            if not sta_if.isconnected():
                print(f"Connecting to Wi-Fi (Attempt {attempt + 1}/5)...")
                sta_if.connect(SSID, PASSWORD)

                for _ in range(20):  # Wait up to 10 seconds
                    if sta_if.isconnected():
                        print(f"Wi-Fi connected: {sta_if.ifconfig()[0]}")
                        return
                    await asyncio.sleep(0.5)

            if sta_if.isconnected():
                print(f"Wi-Fi already connected: {sta_if.ifconfig()[0]}")
                return

        except OSError as e:
            print(f"Wi-Fi connection error: {e}. Retrying...")

        # Exponential backoff before next attempt
        await asyncio.sleep(2 ** attempt)

    print("Wi-Fi connection failed after multiple attempts. Rebooting...")
    machine.reset()  # Reboot if all retries fail


async def mpu6050_task():
    """Task to monitor MPU6050 connection, reinitialize if necessary."""
    global mpu6050_initialized, offsets

    while True:
        try:
            # Detect MPU6050 connection
            if await detect_mpu6050():
                print("MPU6050 detected.")
                if not mpu6050_initialized:
                    print("MPU6050 detected but not initialized. Attempting initialization...")
                    offsets = (0, 0, 0)  # Clear offsets before reinitializing
                    success = await initialize_mpu6050()
                    if success:
                        mpu6050_initialized = True
                        print("MPU6050 initialized successfully.")
                    else:
                        print("Initialization failed. Retrying in 5 seconds...")
                        await asyncio.sleep(5)
                        continue  # Retry after waiting
                else:
                    print("MPU6050 already initialized.")
            else:
                print("MPU6050 not detected. Resetting state...")
                mpu6050_initialized = False
                offsets = (0, 0, 0)  # Clear offsets

            # If initialized, read RMS values
            if mpu6050_initialized:
                ax_rms, ay_rms, az_rms = await calculate_rms(i2c, offsets, num_samples=100)
                print(f"RMS Values: ax={ax_rms:.2f}, ay={ay_rms:.2f}, az={az_rms:.2f}")

        except Exception as e:
            print(f"MPU6050 task error: {e}")
            # Mark sensor as not initialized to trigger reinitialization
            mpu6050_initialized = False

        await asyncio.sleep(5)  # Delay before next iteration


async def temperature_task():
    """Publish temperature and accelerometer readings with error handling."""
    client = None
    firmware_version = get_firmware_version()  # Read firmware version once during initialization
    
    while True:
        try:
            # Ensure MQTT client is connected
            if client is None:
                print("MQTT client is None, attempting to reconnect...")
                client = await connect_mqtt()
                if client is None:
                    print("Failed to reconnect MQTT client, retrying after delay.")
                    await asyncio.sleep(5)
                    continue
            
            # Check for incoming MQTT messages
            client = await check_mqtt_messages(client)
            
            # Read accelerometer data if MPU6050 is initialized
            if mpu6050_initialized:
                try:
                    ax, ay, az = await calculate_rms(i2c, offsets)
                except Exception as e:
                    print(f"Error reading accelerometer data: {e}")
                    ax, ay, az = None, None, None
            else:
                ax, ay, az = None, None, None
            
            # Read temperature data
            try:
                temperature = sensors[0].temperature
                if temperature is None:
                    raise ValueError("Temperature data is None")
            except Exception as e:
                print(f"Error reading temperature data: {e}")
                temperature = 999  # Default value for invalid temperature
            
            # Prepare data string
            data = (
                f"AccX: {ax if ax is not None else '0.0'}, "
                f"AccY: {ay if ay is not None else '0.0'}, "
                f"AccZ: {az if az is not None else '0.0'}, "
                f"Temp: {temperature:.2f}C, FW: {firmware_version}"
            )
            
            # Publish the data
            client = await publish_data(client, data)
            
            # Delay before the next cycle
            await asyncio.sleep(5)
        
        except Exception as e:
            print(f"Error in temperature task: {e}")
            # Handle specific errors
            if str(e) == "[Errno 104] ECONNRESET":
                print("MQTT connection reset by broker. Reconnecting...")
                client = await reconnect_mqtt(client)
            elif str(e) == "-1":
                print("Error -1 detected, attempting reconnection...")
                client = await reconnect_mqtt(client)
            else:
                print(f"Unhandled error in temperature task: {e}")
                await asyncio.sleep(5)  # Delay before retrying

async def led_blink_task():
    """Blink LED as a heartbeat."""
    while True:
        led.value(1)
        await asyncio.sleep(0.5)
        led.value(0)
        await asyncio.sleep(0.5)
        
async def ota_task():
    retries = 0
    while retries < 5:
        try:
            # Create OTAUpdater instance with configuration
            ota_updater = OTAUpdater(SSID, PASSWORD, FIRMWARE_URL, "main.py", NODE_ID)
            
            # Check for updates
            if await ota_updater.check_for_updates():
                # Perform OTA update and reset device
                ota_updater.update_and_reset()
                return  # Exit if update is successful
            else:
                print("No update available.")
            
            # Reset retry count if no update
            retries = 0
        except Exception as e:
            retries += 1
            print(f"Error in OTA update: {e}. Retry {retries}/5")
        
        # Wait for 2 minutes before retrying
        await asyncio.sleep(30)


# Main function
async def main():
    """Run all tasks."""
    await connect_wifi()
    await asyncio.gather(
        led_blink_task(),
        mqtt_task(),
        temperature_task(),
        mpu6050_task(),
        ota_task(),
    )

# Run the main function
asyncio.run(main())
