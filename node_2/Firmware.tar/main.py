# main.py

# Ensure configuration files exist
import gc  # Import garbage collection at the top

def create_config_file():
    """Create or overwrite config.py with necessary configuration."""
    config_code = '''
# Wi-Fi Configuration
SSID = "Ramniwas"
PASSWORD = "lasvegas@007"

# OTA Configuration
FIRMWARE_URL = "https://github.com/atonughosh/tsdpl_vib_temp"
NODE_ID = 2

# MQTT Configuration
BROKER = "13.232.192.17"
PORT = 1883
TOPIC = "esp32/data"
REBOOT_TOPIC = "remote_control"
'''
    try:
        with open("config.py", "w") as f:
            f.write(config_code)
        print("config.py created successfully.")
    except Exception as e:
        print(f"Failed to create config.py: {e}")
    finally:
        gc.collect()  # Collect garbage after file operation

def create_boot_file():
    """Create or overwrite boot.py with the necessary content."""
    boot_code = '''
import gc
import time

try:
    from config import SSID, PASSWORD, FIRMWARE_URL, NODE_ID, BROKER, PORT, TOPIC, REBOOT_TOPIC
except ImportError:
    print("Error: config.py not found!")
    SSID = ""
    PASSWORD = ""
    FIRMWARE_URL = ""
    NODE_ID = ""
    BROKER = ""
    PORT = 1883
    TOPIC = ""
    REBOOT_TOPIC = ""

# OTA update logic
from ota import OTAUpdater
import uasyncio as asyncio

async def boot_time_ota():
    # Perform OTA updates during boot
    print("Starting boot time OTA process...")
    try:
        # Perform OTA update
        ota_updater = OTAUpdater(SSID, PASSWORD, FIRMWARE_URL, "main.py", NODE_ID)
        await asyncio.sleep(5)  # Allow Wi-Fi to stabilize

        # Check for updates
        await ota_updater.update_and_reset()  # Run async update process

    except Exception as e:
        print(f"Error during OTA update: {e}")

    gc.collect()

# To start the OTA process:
asyncio.run(boot_time_ota())
gc.collect()
'''
    try:
        with open("boot.py", "w") as f:
            f.write(boot_code)
        print("boot.py created successfully.")
    except Exception as e:
        print(f"Failed to create boot.py: {e}")
    finally:
        gc.collect()  # Collect garbage after file operation

create_config_file()
create_boot_file()

import machine
import uasyncio as asyncio
import json
import os
import math
from machine import Pin, I2C, SoftSPI
from umqtt.simple import MQTTClient
import max31865
from ota import OTAUpdater
from config import SSID, PASSWORD, BROKER, PORT, TOPIC, REBOOT_TOPIC, FIRMWARE_URL, NODE_ID
import time
import ujson as json  # Use MicroPython-compatible JSON library
import network
import gc

# Constants
RTD_NOMINAL = 100.0
RTD_REFERENCE = 402.0
RTD_WIRES = 3
MPU6050_ADDR = 0x68
PWR_MGMT_1 = 0x6B

# Hardware Setup
try:
    # SPI and I2C setup
    sck = Pin(18, Pin.OUT)
    mosi = Pin(23, Pin.OUT)
    miso = Pin(19, Pin.IN)
    spi = SoftSPI(baudrate=50000, sck=sck, mosi=mosi, miso=miso, polarity=0, phase=1)
    cs1 = Pin(5, Pin.OUT, value=1)
    css = [cs1]
    sensors = [max31865.MAX31865(spi, cs, wires=RTD_WIRES, rtd_nominal=RTD_NOMINAL, ref_resistor=RTD_REFERENCE) for cs in css]

    # I2C setup for MPU6050
    scl_pin = Pin(22)
    sda_pin = Pin(21)
    i2c = I2C(0, scl=scl_pin, sda=sda_pin, freq=400000)
except Exception as e:
    print(f"Error during hardware initialization: {e}")
    sensors = []
    i2c = None
finally:
    gc.collect()  # Collect garbage after hardware setup

# LED setup
led = Pin(2, Pin.OUT)

# Shared state for MPU6050
mpu6050_initialized = False
offsets = (0, 0, 0)  # Placeholder for accelerometer offsets

# Global MQTT client instance
mqtt_client = None

def get_firmware_version():
    """Read the firmware version from version.json."""
    try:
        with open("version.json", "r") as f:
            version_data = json.load(f)
            return version_data.get("version", "unknown")  # Default to 'unknown' if key is missing
    except (OSError, ValueError, KeyError) as e:
        print(f"Error reading version.json: {e}")
        return "unknown"
    finally:
        gc.collect()  # Collect garbage after reading the version file

def on_message(topic, msg):
    """Handle incoming MQTT messages."""
    try:
        decoded_topic = topic.decode('utf-8')
        decoded_msg = msg.decode('utf-8')
        print(f"Message received on topic {decoded_topic}: {decoded_msg}")

        # Handle reboot command
        if decoded_topic == REBOOT_TOPIC and decoded_msg == "reboot":
            print("Reboot command received. Restarting...")
            machine.reset()
        else:
            print("Received unrecognized command.")
    except UnicodeError as e:
        print(f"Error decoding message: {e}")
    except Exception as e:
        print(f"Error in on_message callback: {e}")
    finally:
        gc.collect()  # Collect garbage after processing the message

async def connect_mqtt():
    """Establish a connection to the MQTT broker."""
    global mqtt_client
    retries = 0
    max_retries = 5
    while retries < max_retries:
        try:
            mqtt_client = MQTTClient("esp32_client", BROKER, port=PORT, keepalive=60)
            mqtt_client.set_callback(on_message)
            mqtt_client.connect()
            mqtt_client.subscribe(REBOOT_TOPIC)
            print(f"Connected to MQTT broker at {BROKER}:{PORT} and subscribed to {REBOOT_TOPIC}")
            return mqtt_client
        except Exception as e:
            retries += 1
            print(f"MQTT connection failed: {e}. Retry {retries}/{max_retries}")
            await asyncio.sleep(5)
            gc.collect()  # Collect garbage after failed connection attempt
    print("Failed to connect to MQTT broker after multiple attempts.")
    return None

async def reconnect_mqtt():
    """Reconnect to the MQTT broker."""
    global mqtt_client
    try:
        if mqtt_client:
            mqtt_client.disconnect()
            mqtt_client = None
            gc.collect()  # Collect garbage after disconnecting
        print("Reconnecting to MQTT broker...")
        return await connect_mqtt()
    except Exception as e:
        print(f"Error during MQTT reconnection: {e}")
        return None

async def publish_data(client, data):
    """Publish data to the MQTT broker with error handling."""
    if client:
        try:
            client.publish(TOPIC, data.encode('utf-8'))  # Ensure data is encoded
        except Exception as e:
            print(f"Error publishing data: {e}")
            client = await reconnect_mqtt()
        finally:
            gc.collect()  # Collect garbage after publishing
    else:
        print("MQTT client is None. Reconnecting...")
        client = await reconnect_mqtt()
    return client

async def check_mqtt_messages(client):
    """Check for incoming MQTT messages."""
    try:
        if client:
            client.check_msg()
        else:
            client = await reconnect_mqtt()
    except Exception as e:
        print(f"Error checking MQTT messages: {e}")
        client = await reconnect_mqtt()
    finally:
        gc.collect()  # Collect garbage after checking messages
    return client

async def mqtt_task():
    """Handle MQTT connections and messages."""
    global mqtt_client, ax, ay, az
    mqtt_client = await connect_mqtt()
    firmware_version = get_firmware_version()
    last_print_time = time.time()

    while True:
        try:
            if mqtt_client:
                mqtt_client = await check_mqtt_messages(mqtt_client)

                # Read accelerometer data
                if mpu6050_initialized:
                    ax, ay, az = await calculate_rms(i2c, offsets)
                else:
                    ax, ay, az = 0.0, 0.0, 0.0

                # Read temperature data
                try:
                    if sensors:
                        temperature = sensors[0].temperature
                        if temperature is None:
                            raise ValueError("Temperature data is None")
                    else:
                        temperature = 999  # Default value if sensor is not initialized
                except Exception as e:
                    print(f"Error reading temperature data: {e}")
                    temperature = 999  # Default value

                # Prepare the data
                data = (
                    f"AccX: {ax:.2f}, "
                    f"AccY: {ay:.2f}, "
                    f"AccZ: {az:.2f}, "
                    f"Temp: {temperature:.2f}C, FW: {firmware_version}"
                )

                mqtt_client = await publish_data(mqtt_client, data)

                # Print status every 20 seconds
                current_time = time.time()
                if current_time - last_print_time >= 20:
                    print(f"Published data: {data}")
                    last_print_time = current_time
            else:
                print("MQTT client is disconnected. Reconnecting...")
                mqtt_client = await reconnect_mqtt()
        except Exception as e:
            print(f"Error in MQTT task: {e}")
            mqtt_client = await reconnect_mqtt()
        finally:
            gc.collect()  # Collect garbage after each loop iteration

        await asyncio.sleep(5)  # Adjust the interval as needed

async def detect_mpu6050():
    """Check if the MPU6050 is connected."""
    try:
        if i2c:
            data = i2c.readfrom_mem(MPU6050_ADDR, 0x75, 1)  # WHO_AM_I register
            detected = data[0] == 0x68  # MPU6050 WHO_AM_I value is 0x68
            return detected
        else:
            print("I2C interface not initialized.")
            return False
    except Exception as e:
        print(f"Error during MPU6050 detection: {e}")
        return False
    finally:
        gc.collect()  # Collect garbage after detection

async def initialize_mpu6050():
    """Initialize the MPU6050 sensor."""
    global offsets
    try:
        if not i2c:
            print("I2C interface not initialized.")
            return False

        # Reset the MPU6050 (optional but recommended)
        i2c.writeto_mem(MPU6050_ADDR, PWR_MGMT_1, b'\x80')  # Reset MPU6050
        await asyncio.sleep(0.1)  # Short delay for reset to complete

        # Wake up the MPU6050
        i2c.writeto_mem(MPU6050_ADDR, PWR_MGMT_1, b'\x00')

        # Configure basic settings
        i2c.writeto_mem(MPU6050_ADDR, 0x1A, b'\x03')  # Set DLPF to 44Hz
        i2c.writeto_mem(MPU6050_ADDR, 0x1B, b'\x00')  # Set Gyroscope to ±250°/s
        i2c.writeto_mem(MPU6050_ADDR, 0x1C, b'\x00')  # Set Accelerometer to ±2g

        # Perform calibration
        offsets = await calibrate_mpu6050(i2c)
        return True
    except Exception as e:
        print(f"Failed to initialize MPU6050: {e}")
        return False
    finally:
        gc.collect()  # Collect garbage after initialization

async def calibrate_mpu6050(i2c):
    num_samples = 1000
    ax_offset, ay_offset, az_offset = 0, 0, 0
    try:
        for _ in range(num_samples):
            ax = await read_i2c_word(i2c, 0x3B)
            ay = await read_i2c_word(i2c, 0x3D)
            az = await read_i2c_word(i2c, 0x3F)
            ax_offset += ax
            ay_offset += ay
            az_offset += az
        ax_offset /= num_samples
        ay_offset /= num_samples
        az_offset /= num_samples
        az_offset -= 16384  # Adjust for gravity
    except Exception as e:
        print(f"Calibration error: {e}")
        ax_offset, ay_offset, az_offset = 0, 0, 0  # Reset offsets on error
    finally:
        gc.collect()  # Collect garbage after calibration
    return ax_offset, ay_offset, az_offset

async def read_i2c_word(i2c, register):
    try:
        data = i2c.readfrom_mem(MPU6050_ADDR, register, 2)
        value = (data[0] << 8) | data[1]
        if value >= 0x8000:
            value -= 0x10000
        return value
    except Exception as e:
        print(f"Error reading I2C word: {e}")
        return 0

async def read_accel(i2c, offsets):
    ax_offset, ay_offset, az_offset = offsets
    try:
        ax = await read_i2c_word(i2c, 0x3B) - ax_offset
        ay = await read_i2c_word(i2c, 0x3D) - ay_offset
        az = await read_i2c_word(i2c, 0x3F) - az_offset
        return ax / 16384.0, ay / 16384.0, az / 16384.0
    except Exception as e:
        print(f"Error reading accelerometer: {e}")
        return 0.0, 0.0, 0.0

async def calculate_rms(i2c, offsets, num_samples=100):
    ax_squared, ay_squared, az_squared = 0, 0, 0
    try:
        for _ in range(num_samples):
            ax, ay, az = await read_accel(i2c, offsets)
            ax_squared += ax ** 2
            ay_squared += ay ** 2
            az_squared += az ** 2
        ax_rms = math.sqrt(ax_squared / num_samples)
        ay_rms = math.sqrt(ay_squared / num_samples)
        az_rms = math.sqrt(az_squared / num_samples)
    except Exception as e:
        print(f"Error calculating RMS: {e}")
        ax_rms, ay_rms, az_rms = 0.0, 0.0, 0.0
    finally:
        gc.collect()  # Collect garbage after RMS calculation
    return ax_rms, ay_rms, az_rms

async def connect_wifi():
    """Connect to Wi-Fi with retry logic and reboot if it fails multiple times."""
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    retries = 0
    max_retries = 5

    if wlan.isconnected():
        print(f"Wi-Fi already connected: {wlan.ifconfig()[0]}")
        return True

    while retries < max_retries:
        try:
            print("Connecting to Wi-Fi...")
            wlan.connect(SSID, PASSWORD)

            # Wait for connection to establish
            for _ in range(10):  # Wait for up to 20 seconds
                if wlan.isconnected():
                    print(f"Connected to Wi-Fi: {wlan.ifconfig()[0]}")
                    return True
                await asyncio.sleep(2)

            # If connection still not established, increment retry counter
            retries += 1
            print(f"Wi-Fi connection failed. Retry {retries}/{max_retries}.")

        except Exception as e:
            retries += 1
            print(f"Error during Wi-Fi connection: {e}. Retry {retries}/{max_retries}")
            await asyncio.sleep(5)
        finally:
            gc.collect()  # Collect garbage after each connection attempt

    print("Wi-Fi connection failed after multiple attempts. Rebooting...")
    machine.reset()  # Reboot the device if Wi-Fi connection fails after retries
    return False

async def mpu6050_task():
    """Monitor MPU6050 connection and read data."""
    global mpu6050_initialized, offsets
    last_print_time = time.time()

    while True:
        try:
            # Detect MPU6050 connection
            if await detect_mpu6050():
                if not mpu6050_initialized:
                    if await initialize_mpu6050():
                        mpu6050_initialized = True
                else:
                    # Optionally, you can perform periodic tasks here
                    pass
            else:
                mpu6050_initialized = False
                offsets = (0, 0, 0)  # Reset offsets

            # Print status every 20 seconds
            current_time = time.time()
            if current_time - last_print_time >= 20:
                status = "Initialized" if mpu6050_initialized else "Not Initialized"
                print(f"MPU6050 status: {status}")
                last_print_time = current_time

        except Exception as e:
            print(f"MPU6050 task error: {e}")
            mpu6050_initialized = False  # Reset state on error
            offsets = (0, 0, 0)
        finally:
            gc.collect()  # Collect garbage after each loop iteration
        await asyncio.sleep(5)  # Adjust the interval as needed

async def temperature_task():
    """Publish temperature readings with error handling."""
    client = None
    firmware_version = get_firmware_version()
    last_print_time = time.time()

    while True:
        try:
            # Ensure MQTT client is connected
            if client is None:
                client = await connect_mqtt()
                if client is None:
                    await asyncio.sleep(5)
                    continue

            # Check for incoming MQTT messages
            client = await check_mqtt_messages(client)

            # Read temperature data
            try:
                if sensors:
                    temperature = sensors[0].temperature
                    if temperature is None:
                        raise ValueError("Temperature data is None")
                else:
                    temperature = 999  # Default value if sensor is not initialized
            except Exception as e:
                print(f"Error reading temperature data: {e}")
                temperature = 999  # Default value

            # Prepare data string
            data = f"Temp: {temperature:.2f}C, FW: {firmware_version}"

            # Publish the data
            client = await publish_data(client, data)

            # Print status every 20 seconds
            current_time = time.time()
            if current_time - last_print_time >= 20:
                print(f"Published temperature data: {data}")
                last_print_time = current_time

            # Delay before the next cycle
            await asyncio.sleep(5)

        except Exception as e:
            print(f"Error in temperature task: {e}")
            client = await reconnect_mqtt()
            await asyncio.sleep(5)
        finally:
            gc.collect()  # Collect garbage after each loop iteration

async def led_blink_task():
    """Blink LED as a heartbeat."""
    while True:
        try:
            led.value(1)
            await asyncio.sleep(0.5)
            led.value(0)
            await asyncio.sleep(0.5)
        except Exception as e:
            print(f"Error in LED blink task: {e}")
            await asyncio.sleep(1)  # Wait before retrying
        finally:
            gc.collect()  # Collect garbage after blinking

async def ota_task():
    """Perform OTA updates periodically."""
    retries = 0
    max_retries = 5
    last_print_time = time.time()

    while True:
        try:
            # Initialize OTA Updater
            ota_updater = OTAUpdater(SSID, PASSWORD, FIRMWARE_URL, "main.py", NODE_ID)

            # Check if there is a new firmware version available
            if await ota_updater.check_for_updates():
                print("New firmware version available. Performing OTA update...")
                await ota_updater.update_and_reset()
                print("OTA update completed successfully.")
                return  # Exit the task after successful update
            else:
                pass  # No updates available

            retries = 0  # Reset retries if no update is available

            # Print status every 20 seconds
            current_time = time.time()
            if current_time - last_print_time >= 20:
                print("OTA check completed. No updates available.")
                last_print_time = current_time

        except Exception as e:
            retries += 1
            print(f"Error in OTA update: {e}. Retry {retries}/{max_retries}")
            if retries >= max_retries:
                print("Max retries reached for OTA update. Resetting retries.")
                retries = 0  # Reset retries after max retries
        finally:
            gc.collect()  # Collect garbage after OTA check

        # Sleep between OTA checks (e.g., every 15 minutes)
        await asyncio.sleep(900)  # Adjust the interval as needed

async def main():
    """Run all tasks."""
    try:
        # Connect to Wi-Fi first
        if not await connect_wifi():
            print("Wi-Fi connection failed. Rebooting...")
            machine.reset()  # Optionally reboot or continue without Wi-Fi

        # Create and schedule tasks to run concurrently
        tasks = [
            asyncio.create_task(led_blink_task()),
            asyncio.create_task(mqtt_task()),
            asyncio.create_task(temperature_task()),
            asyncio.create_task(mpu6050_task()),
            asyncio.create_task(ota_task()),
        ]

        # Keep the main function alive
        while True:
            await asyncio.sleep(3600)  # Adjust as needed

    except Exception as e:
        print(f"Error in main function: {e}")
        # Decide whether to reboot or continue
        machine.reset()
    finally:
        gc.collect()  # Collect garbage before exiting main

# Run the main function
asyncio.run(main())
